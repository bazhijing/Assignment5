package iss.java.mail;

import java.io.IOException;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;

/**
 * 实现了IMailService接口，用于实际的email操作
 * 
 * @author bazhijing
 * 
 * 
 */
public class mail2014302580178 implements IMailService {
	private String my_mail = "paopaoluojingmin@163.com";
	private String password = "";
	private String send_smtp_address = "smtp.163.com";
	private String receive_imap_address = "imap.163.com";
	private Properties props;
	private Session session;
	private MimeMessage email;

	/**
	 * 初始化连接设定
	 * 
	 * @throws MessagingException
	 *             初始化或连接异常
	 */
	public void connect() throws MessagingException {
		// 设置属性
		if (props == null)
			props = System.getProperties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", send_smtp_address);
		props.put("mail.store.protocol", "imap");
		props.put("mail.imap.host", receive_imap_address);
		// 创建session
		session = Session.getDefaultInstance(props, null);
		email = new MimeMessage(session);
	}

	/**
	 * 发送单封邮件，mime发送，有需要还可以加附件代码块哦！
	 * 
	 * @param recipient
	 *            收件人邮箱地址
	 * @param subject
	 *            邮件主题
	 * @param content
	 *            邮件正文
	 * @throws MessagingException
	 *             发送邮件错误
	 */
	public void send(String recipient, String subject, Object content) throws MessagingException {
		email.setSubject(subject);
		email.setFrom(new InternetAddress(my_mail));
		email.setRecipients(javax.mail.Message.RecipientType.TO, InternetAddress.parse(recipient));
		MimeMultipart mp = new MimeMultipart();
		BodyPart bp = new MimeBodyPart();
		bp.setContent("<meta http-equiv=Content-Type content=text/html ;charset=UTF-8> " + content,
				"text/html;charset=UTF-8");
		mp.addBodyPart(bp);
		email.setContent(mp);
		email.saveChanges();
		Session emailSession = Session.getInstance(props);
		Transport transport = emailSession.getTransport("smtp");
		transport.connect((String) props.getProperty("mail.smtp.host"), my_mail, password);
		transport.sendMessage(email, email.getRecipients(javax.mail.Message.RecipientType.TO));
		System.out.println("发送完毕");
		transport.close();

	}

	/**
	 * 询问服务器是否有新邮件到达
	 * 使用imap协议的特有函数，pop3就不行了
	 * @return 布朗值，指示是否有新邮件
	 * @throws MessagingException
	 *             询问服务器出错
	 */
	public boolean listen() throws MessagingException {
		Session emailSession = Session.getInstance(props);
		IMAPStore store = (IMAPStore) emailSession.getStore("imap");
		store.connect(my_mail, password);
		IMAPFolder folder = (IMAPFolder) store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);

		if (folder.getNewMessageCount() > 0) {
			System.out.println("新消息： " + folder.getNewMessageCount());
			System.out.println("未读消息： " + folder.getUnreadMessageCount());
			return true;
		}
		folder.close(false);
		store.close();

		return false;
	}

	/**
	 * 接收自动回复的内容，并转换为字符串 
	 * 通过先接收一组message在进行处理的方式获取最新邮件
	 * 
	 * @param sender
	 *            自动回复的发件人邮箱地址
	 * @param subject
	 *            自动回复的主题
	 * @return 自动回复的内容字符串
	 * @throws MessagingException
	 *             查询邮件异常
	 * @throws IOException
	 *             下载邮件异常
	 */
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		Session emailSession = Session.getInstance(props);
		IMAPStore store = (IMAPStore) emailSession.getStore("imap");
		store.connect(my_mail, password);
		IMAPFolder folder = (IMAPFolder) store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		Message[] messages = folder.getMessages();
		int number = -1;
		for (Message message : messages) {
			number = message.getMessageNumber();

		}

		Message message = folder.getMessage(number);
		return message.getContent().toString();
	}

}
